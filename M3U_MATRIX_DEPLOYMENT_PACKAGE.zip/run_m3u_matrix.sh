#!/bin/bash
echo "Starting M3U MATRIX PRO..."
cd src
python3 M3U_MATRIX_PRO.py
