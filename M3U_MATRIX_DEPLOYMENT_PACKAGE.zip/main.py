#!/usr/bin/env python3
import os
import sys

os.chdir('src')

if __name__ == "__main__":
    from M3U_MATRIX_PRO import M3UMatrix
    app = M3UMatrix()
