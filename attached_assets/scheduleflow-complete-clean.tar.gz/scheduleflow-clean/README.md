# ScheduleFlow - Professional Playout Scheduler

Professional-grade HTML/CSS/JavaScript playout scheduler for 24/7 broadcasting. Pure frontend with zero backend dependencies.

## Features
- ✅ M3U playlist import with series detection
- ✅ 24-hour intelligent auto-scheduling
- ✅ 4-week calendar visualization
- ✅ Export to CasparCG, OBS, M3U, JSON
- ✅ Auto-rotating demo player
- ✅ 24/7 internet radio station
- ✅ 30+ automated tests
- ✅ Works offline, no dependencies

## Quick Start

### Local Testing (Replit)
```bash
cd web
node server.js
# Visit http://localhost:5000
```

### Deployment (GitHub Pages)
1. Push to GitHub repository
2. Go to Settings → Pages
3. Select main branch as source
4. Site published at `https://yourusername.github.io/repo-name`

## Modules

| Module | Purpose |
|--------|---------|
| index.html | Hub with module navigation |
| scheduler.html | M3U import + auto-schedule |
| demo.html | Auto-rotating demo (4 shows) |
| calendar.html | 4-week grid viewer |
| export.html | CasparCG, OBS, M3U, JSON exports |
| radio.html | 24/7 internet radio station |
| test.html | 30+ automated tests |

## Data Storage
- Browser localStorage (no server needed)
- Survives refresh/closure
- Export as JSON for backup

## Theme
- BLACK (#000)
- GREEN (#00ff00)
- YELLOW (#ffff00)

## File Structure
```
├── index.html          # Main hub
├── scheduler.html      # M3U scheduler
├── demo.html          # Demo player
├── calendar.html      # Calendar view
├── export.html        # Export tools
├── radio.html         # Radio station
├── test.html          # Test dashboard
├── assets/
│   ├── css/style.css  # Global theme
│   └── js/
│       ├── app.js     # Core utilities
│       └── test.js    # Test suite
├── web/
│   └── server.js      # Local dev server
└── .gitignore
```

## Status
**Production-ready.** GitHub Pages deployment ready. Tested with 30+ automated tests.
