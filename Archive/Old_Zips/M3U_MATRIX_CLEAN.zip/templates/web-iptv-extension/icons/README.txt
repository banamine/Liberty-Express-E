ICON PLACEHOLDER

Add your custom icons here:
- icon16.png (16x16 pixels)
- icon48.png (48x48 pixels)  
- icon128.png (128x128 pixels)

These icons are used for the Chrome extension.

A sample icon.svg file has been provided as a reference.
You can convert it to PNG using online tools or image editors.
