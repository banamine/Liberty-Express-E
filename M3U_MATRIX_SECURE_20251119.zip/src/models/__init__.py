"""
M3U Matrix Data Models
Contains data structures and schemas
"""

__all__ = ['channel', 'playlist', 'schedule']
